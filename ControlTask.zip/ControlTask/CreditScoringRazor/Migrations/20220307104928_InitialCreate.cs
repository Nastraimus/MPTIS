﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace CreditScoringRazor.Migrations
{
    public partial class InitialCreate : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "Clients",
                columns: table => new
                {
                    ID = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Age = table.Column<int>(nullable: false),
                    Income = table.Column<int>(nullable: false),
                    EmpLength = table.Column<int>(nullable: false),
                    HomeOwnership = table.Column<string>(nullable: true),
                    LoanIntent = table.Column<string>(nullable: true),
                    LoanGrade = table.Column<string>(nullable: true),
                    LoanAmount = table.Column<int>(nullable: false),
                    LInterestRate = table.Column<decimal>(nullable: false),
                    PDefault = table.Column<string>(nullable: true),
                    CreditHistoryLength = table.Column<int>(nullable: false),
                    LoanStatus = table.Column<bool>(nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Clients", x => x.ID);
                });
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "Clients");
        }
    }
}
