﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace CreditScoringRazor.Models
{
    public class Clients
    {
        public int ID { get; set; }
        [Display(Name = "Возраст")]
        [Required]
        [Range(18, 100)]
        public int Age { get; set; }
        [DataType(DataType.Currency)]
        [Display(Name = "Доход")]
        [Required]
        public int Income { get; set; }
        [Display(Name = "Стаж работы")]
        [Range(1, 100)]
        [Required]
        public int EmpLength { get; set; }
        [Display(Name = "Домовладение")]
        [StringLength(60, MinimumLength = 3)]
        [Required]
        public string HomeOwnership { get; set; }
        [Display(Name = "Цель кредита")]
        [StringLength(60, MinimumLength = 3)]
        [Required]
        public string LoanIntent { get; set; }
        [Display(Name = "Класс")]
        [RegularExpression(@"[A,B,C,D,F]")]
        [StringLength(1, MinimumLength = 1)]
        [Required]
        public string LoanGrade { get; set; }
        [Display(Name = "Сумма займа")]
        [DataType(DataType.Currency)]
        [Required]
        public int LoanAmount { get; set; }
        [Display(Name = "Ставка кредитования")]
        [Column(TypeName = "decimal(18, 2)")]
        [Range(0, 99.99)]
        [Required]
        public decimal LInterestRate { get; set; }
        [Display(Name = "Банкротство")]
        [RegularExpression(@"[Y,N]")]
        [StringLength(1, MinimumLength = 1)]
        [Required]
        public string PDefault { get; set; }
        [Display(Name = "Кредитная история")]
        [Range(1, 100)]
        [Required]
        public int CreditHistoryLength { get; set; }
        [Display(Name = "Решение*")]
        [Required]
        public bool LoanStatus { get; set; }





    }
}
