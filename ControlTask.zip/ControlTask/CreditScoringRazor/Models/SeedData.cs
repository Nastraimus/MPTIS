﻿using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;
using CreditScoringRazor.Data;
using System;
using System.Linq;
namespace CreditScoringRazor.Models
{

    public static class SeedData
    {
        public static void Initialize(IServiceProvider serviceProvider)
        {
            using (var context = new CreditScoringRazorContext(
            serviceProvider.GetRequiredService<
            DbContextOptions<CreditScoringRazorContext>>()))
            {
                // Look for any movies.
                if (context.Clients.Any())
                {
                    return; // DB has been seeded
                }
                context.Clients.AddRange(
                new Clients
                {
                    Age = 21,
                    Income = 9600,
                    EmpLength = 5, 
                    HomeOwnership = "OWN",
                    LoanIntent = "EDUCATION",
                    LoanGrade = "B",
                    LoanAmount = 1000,
                    LInterestRate = 11,
                    PDefault = "N",
                    CreditHistoryLength = 2, 
                    LoanStatus = false
                },
                new Clients
                {
                    Age = 25,
                    Income = 9600,
                    EmpLength = 1,
                    HomeOwnership = "MORTAGE",
                    LoanIntent = "MEDICAL",
                    LoanGrade = "C",
                    LoanAmount = 5500,
                    LInterestRate = 13,
                    PDefault = "N",
                    CreditHistoryLength = 3,
                    LoanStatus = true
                },
                new Clients
                {
                    Age = 22,
                    Income = 59000,
                    EmpLength = 12,
                    HomeOwnership = "RENT",
                    LoanIntent = "PERSONAL",
                    LoanGrade = "D",
                    LoanAmount = 35000,
                    LInterestRate = 16,
                    PDefault = "Y",
                    CreditHistoryLength = 3,
                    LoanStatus = true
                },
                new Clients
                {
                    Age = 23,
                    Income = 65600,
                    EmpLength = 4,
                    HomeOwnership = "RENT",
                    LoanIntent = "MEDICAL",
                    LoanGrade = "C",
                    LoanAmount = 35000,
                    LInterestRate = 15,
                    PDefault = "N",
                    CreditHistoryLength = 2,
                    LoanStatus = true
                }
                );
                context.SaveChanges();
            }
        }
    }
}
