﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using CreditScoringRazor.Models;

namespace CreditScoringRazor.Data
{
    public class CreditScoringRazorContext : DbContext
    {
        public CreditScoringRazorContext (DbContextOptions<CreditScoringRazorContext> options)
            : base(options)
        {
        }

        public DbSet<CreditScoringRazor.Models.Clients> Clients { get; set; }
    }
}
