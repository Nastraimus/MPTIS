﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using CreditScoringRazor.Data;
using CreditScoringRazor.Models;

namespace CreditScoringRazor.Pages
{
    public class DetailsModel : PageModel
    {
        private readonly CreditScoringRazor.Data.CreditScoringRazorContext _context;

        public DetailsModel(CreditScoringRazor.Data.CreditScoringRazorContext context)
        {
            _context = context;
        }

        public Clients Clients { get; set; }

        public async Task<IActionResult> OnGetAsync(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            Clients = await _context.Clients.FirstOrDefaultAsync(m => m.ID == id);

            if (Clients == null)
            {
                return NotFound();
            }
            return Page();
        }
    }
}
