﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using CreditScoringRazor.Data;
using CreditScoringRazor.Models;
using Microsoft.AspNetCore.Mvc.Rendering;

namespace CreditScoringRazor.Pages
{
    public class IndexModel : PageModel
    {
        private readonly CreditScoringRazor.Data.CreditScoringRazorContext _context;

        public IndexModel(CreditScoringRazor.Data.CreditScoringRazorContext context)
        {
            _context = context;
        }

        public IList<Clients> Clients { get;set; }
        [BindProperty(SupportsGet = true)]
        public string SearchString { get; set; }
        public SelectList Intent { get; set; }
        [BindProperty(SupportsGet = true)]
        public string MovieGenre { get; set; }

        public async Task OnGetAsync()
        {
            var clients = from m in _context.Clients
                         select m;
            if (!string.IsNullOrEmpty(SearchString))
            {
                clients = clients.Where(s => s.LoanIntent.Contains(SearchString));
            }

            Clients = await clients.ToListAsync();

        }
    }
}
