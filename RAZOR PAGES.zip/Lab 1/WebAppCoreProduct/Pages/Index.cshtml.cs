using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using WebAppCoreProduct.Models;

namespace WebAppCoreProduct.Pages
{
    public class IndexModel : PageModel
    {

        public Product Product { get; set; }
        public string MessageRezult { get; private set; }

        public void OnGet()
        {

        }
       
    }
}
